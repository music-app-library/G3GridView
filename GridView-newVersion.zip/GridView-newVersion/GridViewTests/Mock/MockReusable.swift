//
//  MockReusable.swift
//  GridView
//
//  Created by Kyohei Ito on 2016/12/30.
//  Copyright © 2016年 Kyohei Ito. All rights reserved.
//

import UIKit
@testable import GridView

class MockReusable: Reusable {
    var canReuse = true
}
